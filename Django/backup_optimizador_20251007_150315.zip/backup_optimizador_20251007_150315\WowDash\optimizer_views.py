# optimizer_views.py - Motor de optimización simplificado y robusto
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
import json
import uuid
from datetime import datetime
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import mm
from core.models import Proyecto, Cliente, Material, Tapacanto
import math

class TipoMaterial:
    TABLERO = 'tablero'
    TAPACANTO = 'tapacanto'

class OptimizationEngine:
    """Motor de optimización simplificado que evita superposiciones"""
    
    def __init__(self, tablero_ancho, tablero_largo, margen_x, margen_y, desperdicio_sierra):
        self.tablero_ancho_original = tablero_ancho
        self.tablero_largo_original = tablero_largo
        self.tablero_ancho = tablero_ancho - (2 * margen_x)
        self.tablero_largo = tablero_largo - (2 * margen_y)
        self.margen_x = margen_x
        self.margen_y = margen_y
        self.desperdicio_sierra = desperdicio_sierra
        self.tableros = []
    
    def optimizar_piezas(self, piezas):
        """Algoritmo de optimización principal mejorado con timeout"""
        import time
        tiempo_inicio = time.time()
        timeout_segundos = 30  # Límite de 30 segundos
        
        print(f"Iniciando optimización con tablero {self.tablero_ancho}x{self.tablero_largo}")
        print(f"Timeout configurado: {timeout_segundos} segundos")
        
        # Expandir piezas individuales
        piezas_individuales = []
        for pieza in piezas:
            for i in range(pieza['cantidad']):
                pieza_individual = pieza.copy()
                pieza_individual['id_unico'] = f"{pieza['nombre']}_{i+1}"
                pieza_individual['cantidad'] = 1
                piezas_individuales.append(pieza_individual)
        
        print(f"Total de piezas individuales: {len(piezas_individuales)}")
        
        # Ordenar por múltiples criterios para mejor optimización
        def criterio_ordenamiento(p):
            area = p['ancho'] * p['largo']
            # Priorizar por área (descendente) y luego por dimensión más larga
            max_dim = max(p['ancho'], p['largo'])
            return (-area, -max_dim)
        
        piezas_individuales.sort(key=criterio_ordenamiento)
        
        piezas_no_colocadas = []
        
        # Colocar cada pieza con múltiples intentos
        for i, pieza in enumerate(piezas_individuales):
            # Verificar timeout
            tiempo_transcurrido = time.time() - tiempo_inicio
            if tiempo_transcurrido > timeout_segundos:
                print(f"TIMEOUT ALCANZADO después de {tiempo_transcurrido:.1f} segundos")
                print(f"Se procesaron {i}/{len(piezas_individuales)} piezas")
                # Agregar las piezas restantes como no colocadas
                piezas_no_colocadas.extend(piezas_individuales[i:])
                break
            
            print(f"Colocando pieza {i+1}/{len(piezas_individuales)}: {pieza['nombre']} ({pieza['ancho']}x{pieza['largo']}) [{tiempo_transcurrido:.1f}s]")
            colocada = False
            
            # Intentar en tableros existentes primero (ordenar por eficiencia)
            tableros_ordenados = sorted(self.tableros, key=lambda t: len(t['piezas']), reverse=True)
            
            for tablero in tableros_ordenados:
                if self._colocar_pieza_en_tablero(tablero, pieza):
                    print(f"Pieza colocada en tablero {tablero['id']}")
                    colocada = True
                    break
                
                # Verificar timeout durante la búsqueda
                if time.time() - tiempo_inicio > timeout_segundos:
                    print("Timeout alcanzado durante búsqueda en tableros existentes")
                    break
            
            # Si no cabe en ningún tablero existente, crear uno nuevo
            if not colocada and time.time() - tiempo_inicio <= timeout_segundos:
                print(f"Creando nuevo tablero para pieza {pieza['nombre']}")
                nuevo_tablero = self._crear_nuevo_tablero()
                if self._colocar_pieza_en_tablero(nuevo_tablero, pieza):
                    self.tableros.append(nuevo_tablero)
                    print(f"Pieza colocada en nuevo tablero {nuevo_tablero['id']}")
                    colocada = True
                else:
                    print(f"ERROR: No se pudo colocar la pieza {pieza['nombre']} - demasiado grande para el tablero")
                    piezas_no_colocadas.append(pieza)
            elif not colocada:
                # Timeout alcanzado, agregar como no colocada
                piezas_no_colocadas.append(pieza)
        
        tiempo_total = time.time() - tiempo_inicio
        print(f"\n=== OPTIMIZACIÓN COMPLETADA EN {tiempo_total:.2f} SEGUNDOS ===")
        
        if piezas_no_colocadas:
            print(f"ADVERTENCIA: {len(piezas_no_colocadas)} piezas no se pudieron colocar")
            for pieza in piezas_no_colocadas:
                print(f"  - {pieza['nombre']}: {pieza['ancho']}x{pieza['largo']}")
        
        resultado = self._generar_resultado()
        resultado['piezas_no_colocadas'] = len(piezas_no_colocadas)
        resultado['tiempo_optimizacion'] = tiempo_total
        
        return resultado
    
    def _colocar_pieza_en_tablero(self, tablero, pieza):
        """Intenta colocar una pieza en un tablero específico con verificación estricta"""
        print(f"Intentando colocar {pieza['nombre']} ({pieza['ancho']}x{pieza['largo']})")
        
        # Verificar si la pieza cabe en el tablero
        if (pieza['ancho'] > self.tablero_ancho or pieza['largo'] > self.tablero_largo):
            print(f"Pieza {pieza['nombre']} es demasiado grande para el tablero")
            # Intentar rotación si tiene veta libre
            if (pieza.get('veta_libre', False) and 
                pieza['largo'] <= self.tablero_ancho and 
                pieza['ancho'] <= self.tablero_largo):
                print(f"Intentando rotar pieza {pieza['nombre']}")
                orientaciones = [(pieza['largo'], pieza['ancho'], True)]
            else:
                return False
        else:
            # Probar orientación original primero
            orientaciones = [(pieza['ancho'], pieza['largo'], False)]
            
            # Agregar orientación rotada si tiene veta libre
            if (pieza.get('veta_libre', False) and 
                pieza['largo'] <= self.tablero_ancho and 
                pieza['ancho'] <= self.tablero_largo):
                orientaciones.append((pieza['largo'], pieza['ancho'], True))
        
        # Intentar cada orientación
        for ancho, largo, rotada in orientaciones:
            print(f"Probando orientación: {ancho}x{largo} (rotada: {rotada})")
            posicion = self._encontrar_posicion_libre(tablero, ancho, largo)
            if posicion:
                # Verificación final antes de colocar
                x, y = posicion['x'], posicion['y']
                if (x + ancho <= self.tablero_ancho and y + largo <= self.tablero_largo):
                    nueva_pieza = {
                        'nombre': pieza['nombre'],
                        'id_unico': pieza.get('id_unico', pieza['nombre']),
                        'x': x,
                        'y': y,
                        'ancho': ancho,
                        'largo': largo,
                        'rotada': rotada,
                        'tapacantos': pieza.get('tapacantos', [])
                    }
                    tablero['piezas'].append(nueva_pieza)
                    print(f"Pieza {pieza['nombre']} colocada en ({x}, {y})")
                    return True
                else:
                    print(f"Posición ({x}, {y}) causaría desbordamiento")
        
        print(f"No se pudo colocar pieza {pieza['nombre']}")
        return False
    
    def _encontrar_posicion_libre(self, tablero, ancho, largo):
        """Bottom-Left Fill clásico - busca la posición más abajo y a la izquierda"""
        if ancho > self.tablero_ancho or largo > self.tablero_largo:
            return None
        
        # Si el tablero está vacío, usar esquina bottom-left
        if not tablero['piezas']:
            return {'x': 0, 'y': 0}
        
        mejor_posicion = None
        mejor_y = float('inf')
        mejor_x = float('inf')
        
        # Estrategia 1: Posiciones adyacentes a piezas existentes (más eficiente)
        posiciones_candidatas = self._generar_posiciones_especificas(tablero, ancho, largo)
        
        for x, y in posiciones_candidatas:
            if self._posicion_libre(tablero, x, y, ancho, largo):
                # Bottom-Left: menor Y tiene prioridad absoluta, luego menor X
                if y < mejor_y or (y == mejor_y and x < mejor_x):
                    mejor_y = y
                    mejor_x = x
                    mejor_posicion = {'x': x, 'y': y}
        
        # Estrategia 2: Si no encontró posición adyacente, búsqueda sistemática
        if not mejor_posicion:
            # Usar paso mediano para balance entre velocidad y precisión
            paso = 15
            for y in range(0, self.tablero_largo - largo + 1, paso):
                for x in range(0, self.tablero_ancho - ancho + 1, paso):
                    if self._posicion_libre(tablero, x, y, ancho, largo):
                        if y < mejor_y or (y == mejor_y and x < mejor_x):
                            mejor_y = y
                            mejor_x = x
                            mejor_posicion = {'x': x, 'y': y}
        
        if mejor_posicion:
            print(f"Posición BL encontrada: ({mejor_posicion['x']}, {mejor_posicion['y']})")
        else:
            print("No se encontró posición válida")
            
        return mejor_posicion
    
    def _generar_posiciones_especificas(self, tablero, ancho, largo):
        """Genera posiciones específicas para empaquetamiento óptimo"""
        posiciones = set()  # Usar set para evitar duplicados
        
        # Siempre incluir esquinas del tablero como opciones
        posiciones.add((0, 0))  # Esquina bottom-left
        
        for pieza in tablero['piezas']:
            # A la derecha de la pieza (con margen de sierra)
            x_der = pieza['x'] + pieza['ancho'] + self.desperdicio_sierra
            if x_der + ancho <= self.tablero_ancho:
                # Alineado con el borde inferior de la pieza
                if pieza['y'] + largo <= self.tablero_largo:
                    posiciones.add((x_der, pieza['y']))
                # Alineado con el borde superior de la pieza
                y_sup = pieza['y'] + pieza['largo'] + self.desperdicio_sierra
                if y_sup + largo <= self.tablero_largo:
                    posiciones.add((x_der, y_sup))
            
            # Arriba de la pieza (con margen de sierra)
            y_arr = pieza['y'] + pieza['largo'] + self.desperdicio_sierra
            if y_arr + largo <= self.tablero_largo:
                # Alineado con el borde izquierdo de la pieza
                if pieza['x'] + ancho <= self.tablero_ancho:
                    posiciones.add((pieza['x'], y_arr))
                # Alineado con el borde derecho de la pieza
                x_der = pieza['x'] + pieza['ancho'] + self.desperdicio_sierra
                if x_der + ancho <= self.tablero_ancho:
                    posiciones.add((x_der, y_arr))
            
            # Posiciones alineadas con bordes de la pieza (sin margen extra)
            # Borde izquierdo
            if pieza['x'] + ancho <= self.tablero_ancho and pieza['y'] + largo <= self.tablero_largo:
                posiciones.add((pieza['x'], pieza['y']))
            
            # Borde inferior
            if pieza['x'] + ancho <= self.tablero_ancho and pieza['y'] + largo <= self.tablero_largo:
                posiciones.add((pieza['x'], pieza['y']))
        
        # Convertir a lista y ordenar por prioridad Bottom-Left estricta
        posiciones_lista = list(posiciones)
        posiciones_lista.sort(key=lambda pos: (pos[1], pos[0]))  # Y primero, luego X
        
        return posiciones_lista
    
    def _calcular_distancia_minima_a_piezas(self, tablero, x, y, ancho, largo):
        """Calcula la distancia mínima a otras piezas para mejor empaquetamiento"""
        if not tablero['piezas']:
            return float('inf')
        
        distancia_min = float('inf')
        centro_x = x + ancho // 2
        centro_y = y + largo // 2
        
        for pieza in tablero['piezas']:
            pieza_centro_x = pieza['x'] + pieza['ancho'] // 2
            pieza_centro_y = pieza['y'] + pieza['largo'] // 2
            
            distancia = math.sqrt((centro_x - pieza_centro_x)**2 + (centro_y - pieza_centro_y)**2)
            distancia_min = min(distancia_min, distancia)
        
        return distancia_min
    
    def _posicion_libre(self, tablero, x, y, ancho, largo):
        """Verifica si una posición específica está libre con margen de sierra correcto"""
        # Verificación de límites del tablero
        if (x < 0 or y < 0 or 
            x + ancho > self.tablero_ancho or 
            y + largo > self.tablero_largo):
            return False
        
        # Verificar colisiones con piezas existentes (aplicar margen de sierra correctamente)
        for pieza in tablero['piezas']:
            # Calcular los límites de ambas piezas con margen de sierra
            nuevo_x1, nuevo_y1 = x, y
            nuevo_x2, nuevo_y2 = x + ancho, y + largo
            
            exist_x1, exist_y1 = pieza['x'], pieza['y']
            exist_x2, exist_y2 = pieza['x'] + pieza['ancho'], pieza['y'] + pieza['largo']
            
            # Verificar si las piezas se superponen (con margen de sierra)
            margen = self.desperdicio_sierra
            
            # Si hay superposición en ambos ejes, hay colisión
            overlap_x = not (nuevo_x2 + margen <= exist_x1 or exist_x2 + margen <= nuevo_x1)
            overlap_y = not (nuevo_y2 + margen <= exist_y1 or exist_y2 + margen <= nuevo_y1)
            
            if overlap_x and overlap_y:
                return False  # Hay colisión
        
        return True  # Posición válida
    
    def _crear_nuevo_tablero(self):
        """Crea un nuevo tablero vacío"""
        return {
            'id': len(self.tableros) + 1,
            'ancho': self.tablero_ancho,
            'largo': self.tablero_largo,
            'piezas': [],
            'area_usada': 0
        }
    
    def _generar_resultado(self):
        """Genera el resultado final de la optimización con métricas mejoradas"""
        total_area_tableros = len(self.tableros) * (self.tablero_ancho * self.tablero_largo)
        area_utilizada = 0
        total_piezas = 0
        
        print(f"Generando resultado para {len(self.tableros)} tableros")
        
        # Actualizar área usada en cada tablero y agregar métricas detalladas
        for i, tablero in enumerate(self.tableros):
            area_tablero = 0
            piezas_en_tablero = len(tablero['piezas'])
            
            for pieza in tablero['piezas']:
                area_pieza = pieza['ancho'] * pieza['largo']
                area_utilizada += area_pieza
                area_tablero += area_pieza
                total_piezas += 1
                
                # Validación OBLIGATORIA que la pieza está dentro del tablero
                if (pieza['x'] + pieza['ancho'] > self.tablero_ancho or 
                    pieza['y'] + pieza['largo'] > self.tablero_largo or
                    pieza['x'] < 0 or pieza['y'] < 0):
                    print(f"ERROR CRÍTICO: Pieza {pieza['nombre']} está MAL POSICIONADA!")
                    print(f"  Posición: ({pieza['x']}, {pieza['y']})")
                    print(f"  Tamaño: {pieza['ancho']}x{pieza['largo']}")
                    print(f"  Límites X: 0 a {self.tablero_ancho - pieza['ancho']}")
                    print(f"  Límites Y: 0 a {self.tablero_largo - pieza['largo']}")
                    print(f"  Tablero: {self.tablero_ancho}x{self.tablero_largo}")
                    # Corregir posición forzadamente
                    pieza['x'] = max(0, min(pieza['x'], self.tablero_ancho - pieza['ancho']))
                    pieza['y'] = max(0, min(pieza['y'], self.tablero_largo - pieza['largo']))
                    print(f"  Posición CORREGIDA: ({pieza['x']}, {pieza['y']})")
            
            tablero['area_usada'] = area_tablero
            tablero['area_total'] = self.tablero_ancho * self.tablero_largo
            tablero['area_utilizada'] = area_tablero
            tablero['eficiencia_tablero'] = (area_tablero / (self.tablero_ancho * self.tablero_largo)) * 100
            # Ajustar coordenadas de piezas para incluir márgenes en la visualización
            for pieza in tablero['piezas']:
                pieza['x'] += self.margen_x  # Offset por margen izquierdo
                pieza['y'] += self.margen_y  # Offset por margen inferior
            
            tablero['ancho'] = self.tablero_ancho_original  # Tablero completo para visualización
            tablero['largo'] = self.tablero_largo_original  # Tablero completo para visualización
            tablero['ancho_trabajo'] = self.tablero_ancho    # Área de trabajo efectiva
            tablero['largo_trabajo'] = self.tablero_largo    # Área de trabajo efectiva
            
            print(f"Tablero {i+1}: {piezas_en_tablero} piezas, {tablero['eficiencia_tablero']:.1f}% eficiencia")
        
        eficiencia = (area_utilizada / total_area_tableros * 100) if total_area_tableros > 0 else 0
        
        resultado = {
            'tableros': self.tableros,
            'total_tableros': len(self.tableros),
            'total_piezas': total_piezas,
            'area_utilizada': area_utilizada / 1000000,  # Convertir a m²
            'eficiencia': round(eficiencia, 1),
            'area_total': total_area_tableros / 1000000,  # Convertir a m²
            'desperdicio_sierra': self.desperdicio_sierra,
            'tablero_ancho_efectivo': self.tablero_ancho,
            'tablero_largo_efectivo': self.tablero_largo,
            'tablero_ancho_original': self.tablero_ancho_original,
            'tablero_largo_original': self.tablero_largo_original,
            'margenes': {
                'margen_x': self.margen_x,
                'margen_y': self.margen_y
            }
        }
        
        print(f"Optimización completada: {len(self.tableros)} tableros, {total_piezas} piezas, {eficiencia:.1f}% eficiencia")
        
        return resultado

# Vistas de Django
@login_required
def optimizador_home(request):
    """Página principal del optimizador"""
    proyectos = Proyecto.objects.filter(usuario=request.user).order_by('-fecha_creacion')[:10]
    clientes = Cliente.objects.all()
    tableros = Material.objects.all()
    tapacantos = Tapacanto.objects.all()
    
    context = {
        'proyectos': proyectos,
        'clientes': clientes,
        'tableros': tableros,
        'tapacantos': tapacantos,
    }
    return render(request, 'optimizador/home.html', context)

def optimizador_home_test(request):
    """Página principal del optimizador - SIN AUTENTICACIÓN para testing"""
    proyectos = []  # Lista vacía para testing
    clientes = Cliente.objects.all()
    tableros = Material.objects.all()
    tapacantos = Tapacanto.objects.all()
    
    context = {
        'proyectos': proyectos,
        'clientes': clientes,
        'tableros': tableros,
        'tapacantos': tapacantos,
    }
    return render(request, 'optimizador/home.html', context)

@login_required 
@csrf_exempt
def crear_proyecto_optimizacion(request):
    """Crea un nuevo proyecto de optimización"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            proyecto = Proyecto.objects.create(
                usuario=request.user,
                nombre=data['nombre'],
                cliente_id=data.get('cliente_id'),
                descripcion=data.get('descripcion', ''),
                configuracion=json.dumps(data)
            )
            
            return JsonResponse({
                'success': True,
                'proyecto_id': proyecto.id,
                'message': 'Proyecto creado exitosamente'
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error al crear proyecto: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Método no permitido'})

@login_required
@csrf_exempt  
def optimizar_material(request):
    """Ejecuta la optimización del material"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Obtener configuración del material
            config = data['configuracion_material']
            material_id = config['material_id']
            material = get_object_or_404(Material, id=material_id)
            
            # Dimensiones del tablero - SIEMPRE usar las medidas de los campos editables
            # Estas son la fuente de verdad para la optimización
            ancho_tablero = config.get('ancho_custom') or material.ancho
            largo_tablero = config.get('largo_custom') or material.largo
            
            print(f"Optimización usando dimensiones del tablero: {ancho_tablero}mm x {largo_tablero}mm")
            print(f"Material original: {material.ancho}mm x {material.largo}mm")
            
            # Parámetros de optimización
            margen_x = config.get('margen_x', 0)
            margen_y = config.get('margen_y', 0)
            desperdicio_sierra = config.get('desperdicio_sierra', 3)
            
            # Crear motor de optimización
            engine = OptimizationEngine(
                ancho_tablero, largo_tablero,
                margen_x, margen_y, desperdicio_sierra
            )
            
            # Procesar piezas
            piezas = data['piezas']
            piezas_procesadas = []
            
            for pieza in piezas:
                piezas_procesadas.append({
                    'nombre': pieza['nombre'],
                    'ancho': pieza['ancho'],
                    'largo': pieza['largo'],
                    'cantidad': pieza['cantidad'],
                    'veta_libre': pieza.get('veta_libre', False),
                    'tapacantos': pieza.get('tapacantos', [])
                })
            
            # Ejecutar optimización
            resultado = engine.optimizar_piezas(piezas_procesadas)
            
            # Agregar información del material
            resultado['material'] = {
                'nombre': material.nombre,
                'codigo': material.codigo,
                'ancho_original': material.ancho,
                'largo_original': material.largo,
                'ancho_usado': ancho_tablero,
                'largo_usado': largo_tablero
            }
            
            # Guardar resultado si hay proyecto_id
            if data.get('proyecto_id'):
                proyecto = get_object_or_404(Proyecto, id=data['proyecto_id'])
                proyecto.resultado_optimizacion = json.dumps(resultado)
                proyecto.save()
            
            return JsonResponse({
                'success': True,
                'resultado': resultado
            })
            
        except Exception as e:
            import traceback
            print(f"Error en optimización: {str(e)}")
            print(traceback.format_exc())
            return JsonResponse({
                'success': False,
                'message': f'Error en la optimización: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Método no permitido'})

@login_required
def obtener_material_info(request, material_id):
    """Obtiene información detallada de un material"""
    try:
        material = get_object_or_404(Material, id=material_id)
        
        return JsonResponse({
            'success': True,
            'material': {
                'id': material.id,
                'nombre': material.nombre,
                'codigo': material.codigo,
                'ancho': material.ancho,
                'largo': material.largo,
                'espesor': material.espesor,
                'tipo': material.tipo,
                'precio': float(material.precio) if material.precio else 0
            }
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': f'Error al obtener información del material: {str(e)}'
        })

@login_required
def exportar_json_entrada(request, proyecto_id):
    """Exporta la configuración de entrada en formato JSON"""
    try:
        proyecto = get_object_or_404(Proyecto, id=proyecto_id)
        
        if not proyecto.configuracion:
            messages.error(request, 'No hay configuración para exportar')
            return redirect('optimizador_home')
        
        configuracion = json.loads(proyecto.configuracion)
        
        response = HttpResponse(
            json.dumps(configuracion, indent=2, ensure_ascii=False),
            content_type='application/json; charset=utf-8'
        )
        response['Content-Disposition'] = f'attachment; filename="config_{proyecto.nombre}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json"'
        
        return response
        
    except Exception as e:
        messages.error(request, f'Error al exportar configuración: {str(e)}')
        return redirect('optimizador_home')

@login_required  
def exportar_json_salida(request, proyecto_id):
    """Exporta el resultado de optimización en formato JSON"""
    try:
        proyecto = get_object_or_404(Proyecto, id=proyecto_id)
        
        if not proyecto.resultado_optimizacion:
            messages.error(request, 'No hay resultado de optimización para exportar')
            return redirect('optimizador_home')
        
        resultado = json.loads(proyecto.resultado_optimizacion)
        
        response = HttpResponse(
            json.dumps(resultado, indent=2, ensure_ascii=False),
            content_type='application/json; charset=utf-8'
        )
        response['Content-Disposition'] = f'attachment; filename="resultado_{proyecto.nombre}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json"'
        
        return response
        
    except Exception as e:
        messages.error(request, f'Error al exportar resultado: {str(e)}')
        return redirect('optimizador_home')

@login_required
def exportar_pdf(request, proyecto_id):
    """Exporta el resultado en formato PDF con visualización"""
    try:
        proyecto = get_object_or_404(Proyecto, id=proyecto_id)
        
        if not proyecto.resultado_optimizacion:
            messages.error(request, 'No hay resultado de optimización para exportar')
            return redirect('optimizador_home')
        
        resultado = json.loads(proyecto.resultado_optimizacion)
        
        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="optimizacion_{proyecto.nombre}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf"'
        
        # Crear PDF
        p = canvas.Canvas(response, pagesize=letter)
        width, height = letter
        
        # Título
        p.setFont("Helvetica-Bold", 16)
        p.drawString(50, height - 50, f"Optimización de Material - {proyecto.nombre}")
        
        # Información del resultado
        y_pos = height - 100
        p.setFont("Helvetica", 12)
        
        p.drawString(50, y_pos, f"Total de tableros: {resultado.get('total_tableros', 0)}")
        y_pos -= 20
        p.drawString(50, y_pos, f"Total de piezas: {resultado.get('total_piezas', 0)}")
        y_pos -= 20
        p.drawString(50, y_pos, f"Eficiencia: {resultado.get('eficiencia', 0)}%")
        y_pos -= 20
        p.drawString(50, y_pos, f"Área utilizada: {resultado.get('area_utilizada', 0):.2f} m²")
        
        # Detalles por tablero
        y_pos -= 40
        p.setFont("Helvetica-Bold", 14)
        p.drawString(50, y_pos, "Detalle de tableros:")
        y_pos -= 30
        
        for i, tablero in enumerate(resultado.get('tableros', []), 1):
            p.setFont("Helvetica-Bold", 12)
            p.drawString(50, y_pos, f"Tablero {i}:")
            y_pos -= 20
            
            p.setFont("Helvetica", 10)
            for pieza in tablero.get('piezas', []):
                texto = f"  • {pieza['nombre']} - {pieza['ancho']}x{pieza['largo']}mm"
                if pieza.get('rotada'):
                    texto += " (rotada)"
                p.drawString(70, y_pos, texto)
                y_pos -= 15
                
                if y_pos < 50:  # Nueva página
                    p.showPage()
                    y_pos = height - 50
        
        p.save()
        return response
        
    except Exception as e:
        messages.error(request, f'Error al generar PDF: {str(e)}')
        return redirect('optimizador_home')

@login_required
def proyectos_optimizador(request):
    """Lista de proyectos de optimización"""
    search = request.GET.get('search', '')
    
    proyectos = Proyecto.objects.filter(usuario=request.user)
    
    if search:
        proyectos = proyectos.filter(
            Q(nombre__icontains=search) |
            Q(descripcion__icontains=search)
        )
    
    proyectos = proyectos.order_by('-fecha_creacion')
    
    paginator = Paginator(proyectos, 20)
    page_number = request.GET.get('page')
    proyectos_page = paginator.get_page(page_number)
    
    context = {
        'proyectos': proyectos_page,
        'search': search,
    }
    return render(request, 'optimizador/proyectos.html', context)

def js_test(request):
    """Vista de prueba para JavaScript"""
    return render(request, 'optimizador/test.html')

def optimizador_clean(request):
    """Vista limpia del optimizador sin complejidades"""
    return render(request, 'optimizador/home-clean.html')