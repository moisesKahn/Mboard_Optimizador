from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Cliente(models.Model):
    """Modelo para clientes del sistema"""
    rut = models.CharField(max_length=12, unique=True, verbose_name="RUT")
    nombre = models.CharField(max_length=100, verbose_name="Nombre Completo")
    empresa = models.CharField(max_length=100, blank=True, null=True, verbose_name="Empresa")
    telefono = models.CharField(max_length=15, blank=True, null=True, verbose_name="Teléfono")
    email = models.EmailField(blank=True, null=True, verbose_name="Email")
    direccion = models.TextField(blank=True, null=True, verbose_name="Dirección")
    activo = models.BooleanField(default=True, verbose_name="Activo")
    fecha_creacion = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Creación")
    
    class Meta:
        verbose_name = "Cliente"
        verbose_name_plural = "Clientes"
        ordering = ['nombre']
    
    def __str__(self):
        return f"{self.nombre} ({self.rut})"

class Material(models.Model):
    """Modelo para materiales (tableros, melaminas, etc.)"""
    TIPOS_MATERIAL = [
        ('melamina', 'Melamina'),
        ('mdf', 'MDF'), 
        ('osb', 'OSB'),
        ('terciado', 'Terciado'),
        ('aglomerado', 'Aglomerado'),
        ('otro', 'Otro')
    ]
    
    codigo = models.CharField(max_length=20, unique=True, verbose_name="Código")
    nombre = models.CharField(max_length=100, verbose_name="Nombre del Material")
    tipo = models.CharField(max_length=20, choices=TIPOS_MATERIAL, verbose_name="Tipo de Material")
    espesor = models.DecimalField(max_digits=5, decimal_places=1, verbose_name="Espesor (mm)")
    ancho = models.IntegerField(verbose_name="Ancho (mm)")
    largo = models.IntegerField(verbose_name="Largo (mm)")
    precio_m2 = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Precio por m²")
    stock = models.IntegerField(default=0, verbose_name="Stock Disponible")
    proveedor = models.CharField(max_length=100, blank=True, null=True, verbose_name="Proveedor")
    activo = models.BooleanField(default=True, verbose_name="Activo")
    fecha_creacion = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Creación")
    
    class Meta:
        verbose_name = "Material"
        verbose_name_plural = "Materiales" 
        ordering = ['nombre']
    
    def __str__(self):
        return f"{self.nombre} - {self.espesor}mm ({self.ancho}x{self.largo})"
    
    # Método save original sin validaciones adicionales
    
    @property
    def area_m2(self):
        """Calcula el área del tablero en m²"""
        return (self.ancho * self.largo) / 1000000

class Tapacanto(models.Model):
    """Modelo para tapacantos"""
    codigo = models.CharField(max_length=20, unique=True, verbose_name="Código")
    nombre = models.CharField(max_length=100, verbose_name="Nombre del Tapacanto")
    color = models.CharField(max_length=50, verbose_name="Color")
    ancho = models.DecimalField(max_digits=5, decimal_places=1, verbose_name="Ancho (mm)")
    espesor = models.DecimalField(max_digits=5, decimal_places=2, verbose_name="Espesor (mm)")
    precio_metro = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Precio por Metro")
    stock_metros = models.IntegerField(default=0, verbose_name="Stock en Metros")
    proveedor = models.CharField(max_length=100, blank=True, null=True, verbose_name="Proveedor")
    activo = models.BooleanField(default=True, verbose_name="Activo")
    fecha_creacion = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Creación")
    
    class Meta:
        verbose_name = "Tapacanto"
        verbose_name_plural = "Tapacantos"
        ordering = ['nombre']
    
    def __str__(self):
        return f"{self.nombre} - {self.color} ({self.ancho}x{self.espesor}mm)"

class Proyecto(models.Model):
    """Modelo para proyectos de optimización"""
    ESTADOS = [
        ('borrador', 'Borrador'),
        ('en_proceso', 'En Proceso'),
        ('optimizado', 'Optimizado'),
        ('aprobado', 'Aprobado'),
        ('produccion', 'En Producción'),
        ('completado', 'Completado'),
        ('cancelado', 'Cancelado')
    ]
    
    codigo = models.CharField(max_length=20, unique=True, verbose_name="Código del Proyecto")
    nombre = models.CharField(max_length=200, verbose_name="Nombre del Proyecto")
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, verbose_name="Cliente")
    descripcion = models.TextField(blank=True, null=True, verbose_name="Descripción")
    estado = models.CharField(max_length=20, choices=ESTADOS, default='borrador', verbose_name="Estado")
    fecha_inicio = models.DateField(verbose_name="Fecha de Inicio")
    fecha_entrega = models.DateField(blank=True, null=True, verbose_name="Fecha de Entrega")
    total_materiales = models.IntegerField(default=0, verbose_name="Total de Materiales")
    total_tableros = models.IntegerField(default=0, verbose_name="Total de Tableros")
    total_piezas = models.IntegerField(default=0, verbose_name="Total de Piezas")
    eficiencia_promedio = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="Eficiencia Promedio (%)")
    costo_total = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name="Costo Total")
    archivo_pdf = models.CharField(max_length=200, blank=True, null=True, verbose_name="Archivo PDF")
    # Nuevos campos para el optimizador
    configuracion = models.JSONField(blank=True, null=True, verbose_name="Configuración del Proyecto")
    resultado_optimizacion = models.JSONField(blank=True, null=True, verbose_name="Resultado de Optimización")
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Usuario", related_name="proyectos_optimizador")
    creado_por = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Creado por")
    fecha_creacion = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Creación")
    fecha_modificacion = models.DateTimeField(auto_now=True, verbose_name="Fecha de Modificación")
    
    class Meta:
        verbose_name = "Proyecto"
        verbose_name_plural = "Proyectos"
        ordering = ['-fecha_creacion']
    
    def __str__(self):
        return f"{self.codigo} - {self.nombre}"

class MaterialProyecto(models.Model):
    """Modelo para materiales utilizados en cada proyecto"""
    proyecto = models.ForeignKey(Proyecto, on_delete=models.CASCADE, related_name='materiales_utilizados')
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    tapacanto = models.ForeignKey(Tapacanto, on_delete=models.SET_NULL, null=True, blank=True)
    cantidad_tableros = models.IntegerField(verbose_name="Cantidad de Tableros")
    eficiencia = models.DecimalField(max_digits=5, decimal_places=2, verbose_name="Eficiencia (%)")
    area_utilizada = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Área Utilizada (cm²)")
    costo_material = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Costo del Material")
    
    class Meta:
        verbose_name = "Material del Proyecto"
        verbose_name_plural = "Materiales del Proyecto"
    
    def __str__(self):
        return f"{self.proyecto.codigo} - {self.material.nombre}"

class UsuarioPerfilOptimizador(models.Model):
    """Extensión del modelo User de Django para perfiles de usuario del sistema"""
    ROLES = [
        ('admin', 'Administrador'),
        ('operador', 'Operador'),
        ('cliente', 'Cliente'),
        ('visualizador', 'Solo Visualización')
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="Usuario")
    rol = models.CharField(max_length=20, choices=ROLES, default='operador', verbose_name="Rol")
    telefono = models.CharField(max_length=15, blank=True, null=True, verbose_name="Teléfono")
    empresa = models.CharField(max_length=100, blank=True, null=True, verbose_name="Empresa")
    activo = models.BooleanField(default=True, verbose_name="Activo")
    fecha_ultimo_acceso = models.DateTimeField(blank=True, null=True, verbose_name="Último Acceso")
    
    class Meta:
        verbose_name = "Perfil de Usuario"
        verbose_name_plural = "Perfiles de Usuario"
    
    def __str__(self):
        return f"{self.user.get_full_name()} ({self.rol})"